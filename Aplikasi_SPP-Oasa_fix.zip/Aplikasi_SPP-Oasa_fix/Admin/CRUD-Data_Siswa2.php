<?php
include "../Template-SPP/Header.php";
include "../Template-SPP/Navbar.php";
include "../Template-SPP/Sidebar.php";
?>

      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="card card-statistic-2">
                <div class="card-stats">
                  <div class="card-stats-title text-center"><h1>DATA SISWA</h1> 
                  </div>
                      <div class="card-stats-items">
                        <div class="card-stats-item">
                          <div class="card-stats-item-count">1.512</div>
                          <div class="card-stats-item-label">Jumlah Seluruh Siswa</div>
                        </div>
                        <div class="card-stats-item">
                          <div class="card-stats-item-count">324</div>
                          <div class="card-stats-item-label">Jumlah Siswa RPL</div>
                        </div>
                        <div class="card-stats-item">
                          <div class="card-stats-item-count">216</div>
                          <div class="card-stats-item-label">Jumlah Siswa DPIB</div>
                        </div>
                        <div class="card-stats-item">
                          <div class="card-stats-item-count">324</div>
                          <div class="card-stats-item-label">Jumlah Siswa TAV</div>
                        </div>
                        <div class="card-stats-item">
                          <div class="card-stats-item-count">324</div>
                          <div class="card-stats-item-label">Jumlah Siswa TKRO</div>
                        </div>
                        <div class="card-stats-item">
                          <div class="card-stats-item-count">324</div>
                          <div class="card-stats-item-label">Jumlah Siswa TBSM</div>
                        </div>
                      </div>
                </div>

                <div class="card-warp">
                  <div class="card-header">

                  </div>
                  <div class="card-body">

                  </div>
                </div>
              </div>

         
              <div class="row">
          <div class="container-fluid">
            <?php
              if(isset($_GET['pesan'])){
                $pesan = $_GET['pesan'];
                if($pesan == "input"){
                  echo "<div class='alert alert-success alert-dismissible fade show'><i class='fas fa-exclamation-circle'></i> Data berhasil diinput.
                 
                </div>";
                }elseif($pesan == "update"){
                 echo "<div class='alert alert-success alert-dismissible fade show'><i class='fas fa-exclamation-circle'></i> Data berhasil diupdate.
                 
                 </div> ";
                }elseif($pesan == "hapus"){
                 echo "<div class='alert alert-success alert-dismissible fade show'><i class='fas fa-exclamation-circle'></i> Data berhasil dihapus.
                  </div>";
                }
              }
            ?>
           <script>window.setTimeout(function(){
            $('.alert').fadeTo(500,0).slideUp(500, function(){
              $(this).remove();
            });
           }, 5000);</script>
            </div>
          </div>

          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="card">
                <div class="card-header">
                  <h4>Data Siswa</h4>
                  <a href="Tambah_Siswa.php" class="btn btn-primary">Tambah Data Siswa</a>
                </div>
                <div class="card-body p-0">
                  <div class="table-responsive table-invoice">
                    <table class="table table-striped">
                    <tr>
                      <th>#</th>
                      <th>NISN</th>
                      <th>NIS</th>
                      <th>Nama Siswa</th>
                      <th>ID Kelas</th>
                      <th>Alamat</th>
                      <th>No Telepon</th>
                      <th>ID SPP</th>
                      <th class="text-center">Action</th>
                    </tr>

                    <?php
                    include "../koneksi.php";
                    $query_mysql = mysqli_query($koneksi,"SELECT * FROM siswa");
                    $nomor = 0;
                    while($data = mysqli_fetch_array($query_mysql)){
                    $nomor++;
                    ?>

                    <tr height='100px'>
                      <td><?php echo $nomor; ?></td>
                      <td><?php echo $data['nisn'];?></td>
                      <td><?php echo $data['nis'];?></td>
                      <td><?php echo $data['nama'];?></td>
                      <td><div class="badge badge-info"><?php echo $data['id_kelas'];?></div></td>
                      <td><?php echo $data['alamat'];?></td>
                      <td><?php echo $data['no_telp'];?></td>
                      <td><?php echo $data['id_spp'];?></td>
                      
                      <td class="text-center">
                        <a href="Edit_Siswa2.php?nisn=<?php echo $data['nisn'];?>" class="btn btn-warning">Edit</a>
                        <a href="Hapus_Siswa.php?nisn=<?php echo $data['nisn'];?>" class="btn btn-danger" onclick="return confirm('Anda yakin akan menghapus data?')">Hapus</a>
                        <a href="#" class="btn btn-primary">Lihat tunggakan</a>
                      </td>
                      </tr>

                      <?php
                    }
                      ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </div> <!-- div container -->

        </section>
      </div>

<?php
include "../Template-SPP/Footer.php";
?>

      
<?php
include "../Template-SPP/Header.php";
include "../Template-SPP/Navbar.php";
include "../Template-SPP/Sidebar.php";
?>

      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="card card-statistic-2">
                <div class="card-stats">
                  <div class="card-stats-title text-center"><h1>DATA SPP</h1> 
                  </div>
                     
                </div>

                <div class="card-warp">
                  <div class="card-header">

                  </div>
                  <div class="card-body">
                  </div>
                </div>
              </div>
                
         
              <div class="row">
          <div class="container-fluid">
            <?php
              if(isset($_GET['pesan'])){
                $pesan = $_GET['pesan'];
                if($pesan == "input"){
                  echo "<div class='alert alert-success alert-dismissible fade show'><i class='fas fa-exclamation-circle'></i> Data berhasil diinput.
                 
                </div>";
                }elseif($pesan == "update"){
                 echo "<div class='alert alert-success alert-dismissible fade show'><i class='fas fa-exclamation-circle'></i> Data berhasil diupdate.
                 
                 </div> ";
                }elseif($pesan == "hapus"){
                 echo "<div class='alert alert-success alert-dismissible fade show'><i class='fas fa-exclamation-circle'></i> Data berhasil dihapus.
                  </div>";
                }
              }
            ?>
           <script>window.setTimeout(function(){
            $('.alert').fadeTo(500,0).slideUp(500, function(){
              $(this).remove();
            });
           }, 5000);</script>
            </div>
          </div>

          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="card">
                <div class="card-header">
                  <h4>Data SPP</h4>
                  <a href="Tambah_SPP.php" class="btn btn-primary">Tambah Data SPP</a>
                </div>
                <div class="card-body p-0">
                  <div class="table-responsive table-invoice">
                    <table class="table table-striped">
                    <tr>
                      <th>#</th>
                      <th>ID SPP</th>
                      <th>Tahun</th>
                      <th>Nominal</th>
                      <th class="text-center">Action</th>
                    </tr>

                    <?php
                    include "../koneksi.php";
                    $query_mysql = mysqli_query($koneksi,"SELECT * FROM spp");
                    $nomor = 0;
                    while($data = mysqli_fetch_array($query_mysql)){
                      $nomor++;
                    ?>

                    <tr>
                      <td><?php echo $nomor; ?></td>
                      <td class="font-weight-600"><?php echo $data['id_spp']; ?></td>
                      <td><div class="badge badge-info"><?php echo $data['tahun'];?></div></td>
                      <td><?php echo $data['nominal'];?></td>
                      <td class="text-center">
                        <a href="Edit_SPP.php?id_spp=<?php echo $data['id_spp'];?>" class="btn btn-warning">Edit</a>
                        <a href="Hapus_SPP.php?id_spp=<?php echo $data['id_spp'];?>" class="btn btn-danger" onclick="return confirm('Anda yakin akan menghapus data?')">Hapus</a>
                      </td>
                      </tr>

                      <?php
                    }
                      ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </div> <!-- div container -->

        </section>
      </div>

<?php
include "../Template-SPP/Footer.php";
?>

      
<?php
include '../koneksi.php';
$id_petugas = $_GET['id_petugas'];
$username = $_POST['username'];
$password = $_POST['password'];
$nama_petugas = $_POST['nama_petugas'];
$level = $_POST['level'];


$query = "UPDATE petugas SET username='" . $username . "',password='" . $password . "',nama_petugas='" . $nama_petugas . "',level='" . $level . "' WHERE id_petugas='" . $id_petugas . "'";
        $sql = mysqli_query($koneksi, $query);

        if ($sql) {
            
header("location:CRUD-Data_Petugas_fix.php?pesan=update
");

        } else {
            echo "Maaf, terjadi kesalahan saat mencoba untuk menyimpan data ke database.";
            echo "<br><a href='Edit_Petugas_fix.php'>Kembali ke form</a>";
        }
?>

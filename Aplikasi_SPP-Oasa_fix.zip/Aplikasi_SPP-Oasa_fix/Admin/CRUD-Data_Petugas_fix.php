<?php
include "../Template-SPP/Header.php";
include "../Template-SPP/Navbar.php";
include "../Template-SPP/Sidebar.php";
?>

      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="card card-statistic-2">
                <div class="card-stats">
                  <div class="card-stats-title text-center"><h1>DATA PETUGAS</h1> 
                  </div>
                      <div class="card-stats-items">
                        <div class="card-stats-item">
                          <div class="card-stats-item-count">42</div>
                          <div class="card-stats-item-label">Jumlah Seluruh Kelas</div>
                        </div>
                        <div class="card-stats-item">
                          <div class="card-stats-item-count">9</div>
                          <div class="card-stats-item-label">Jumlah Kelas RPL</div>
                        </div>
                        <div class="card-stats-item">
                          <div class="card-stats-item-count">6</div>
                          <div class="card-stats-item-label">Jumlah Kelas DPIB</div>
                        </div>
                        <div class="card-stats-item">
                          <div class="card-stats-item-count">9</div>
                          <div class="card-stats-item-label">Jumlah Kelas TAV</div>
                        </div>
                        <div class="card-stats-item">
                          <div class="card-stats-item-count">9</div>
                          <div class="card-stats-item-label">Jumlah Kelas TKRO</div>
                        </div>
                        <div class="card-stats-item">
                          <div class="card-stats-item-count">9</div>
                          <div class="card-stats-item-label">Jumlah Kelas TBSM</div>
                        </div>
                      </div>
                </div>

                <div class="card-warp">
                  <div class="card-header">

                  </div>
                  <div class="card-body">

                  </div>
                </div>
              </div>
                
         
              <div class="row">
          <div class="container-fluid">
            <?php
              if(isset($_GET['pesan'])){
                $pesan = $_GET['pesan'];
                if($pesan == "input"){
                  echo "<div class='alert alert-success alert-dismissible fade show'><i class='fas fa-exclamation-circle'></i> Data berhasil diinput.
                 
                </div>";
                }elseif($pesan == "update"){
                 echo "<div class='alert alert-success alert-dismissible fade show'><i class='fas fa-exclamation-circle'></i> Data berhasil diupdate.
                 
                 </div> ";
                }elseif($pesan == "hapus"){
                 echo "<div class='alert alert-success alert-dismissible fade show'><i class='fas fa-exclamation-circle'></i> Data berhasil dihapus.
                  </div>";
                }
              }
            ?>
           <script>window.setTimeout(function(){
            $('.alert').fadeTo(500,0).slideUp(500, function(){
              $(this).remove();
            });
           }, 5000);</script>
            </div>
          </div>

          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="card">
                <div class="card-header">
                  <h4>Data Petugas</h4>
                  <a href="Tambah_Petugas.php" class="btn btn-primary">Tambah Data Petugas</a>
                </div>
                <div class="card-body p-0">
                  <div class="table-responsive table-invoice">
                    <table class="table table-striped">
                    <tr>
                      <th>#</th>
                      <th>ID Petugas</th>
                      <th>Nama Petugas</th>
                      <th>Username</th>
                      <th>Password</th>
                      <th>Level</th>
                      <th class="text-center">Action</th>
                    </tr>

                    <?php
                    include "../koneksi.php";
                    $query_mysql = mysqli_query($koneksi,"SELECT * FROM petugas");
                    $nomor = 0;
                    while($data = mysqli_fetch_array($query_mysql)){
                    $nomor++;
                    ?>

                    <tr>
                      <td><?php echo $nomor; ?></td>
                      <td class="font-weight-600"><?php echo $data['id_petugas']; ?></td>
                      <td><?php echo $data['nama_petugas'];?></td>
                      <td><?php echo $data['username'];?></td>
                      <td><?php echo $data['password'];?></td>
                      <td><div class="badge badge-info"><?php echo $data['level'];?></div></td>
                     
                      <td class="text-center">
                        <a href="Edit_Petugas_fix.php?id_petugas=<?php echo $data['id_petugas'];?>" class="btn btn-warning">Edit</a>
                        <a href="Hapus_Petugas.php?id_petugas=<?php echo $data['id_petugas'];?>" class="btn btn-danger" onclick="return confirm('Anda yakin akan menghapus data?')">Hapus</a>
                      </td>
                      </tr>

                      <?php
                    }
                      ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </div> <!-- div container -->

        </section>
      </div>

<?php
include "../Template-SPP/Footer.php";
?>

      
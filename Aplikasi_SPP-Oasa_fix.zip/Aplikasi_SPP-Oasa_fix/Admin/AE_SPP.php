<?php
include '../koneksi.php';
$id_spp = $_POST['id_spp'];
$tahun = $_POST['tahun'];
$nominal = $_POST['nominal'];
mysqli_query($koneksi,"UPDATE spp SET tahun='$tahun',nominal='$nominal' WHERE id_spp='$id_spp'"); //data ke edit semua karena belum pake WHERE di kodingan sebelumnya.

header("location:CRUD-Data_SPP.php?pesan=update");
?>
